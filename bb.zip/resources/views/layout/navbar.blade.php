
    <header>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2 text-center">
                    <div class="logo">
                        <img src="assets/images/dashboard/business_bench_logo.svg" alt="">
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="navbar">
                        <ul>
                            <li><a href="javascript:;">Home</a></li>
                            <li><a href="javascript:;">Projects</a></li>
                            <li><a href="javascript:;">Zones</a></li>
                            <li><a href="javascript:;">Region</a></li>
                            <li><a href="javascript:;">Area</a></li>
                            <li><a href="javascript:;">Engineers</a></li>
                            <li><a href="/users">Users</a></li>
                            <li><a href="javascript:;">Clients</a></li>
                            <li><a href="javascript:;">Estimate</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="admin_logo">
                        <img src="" alt="">
                    </div>
                </div>
            </div>
        </div>
    </header>
