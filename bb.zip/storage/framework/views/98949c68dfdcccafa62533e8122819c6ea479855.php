<option selected value="" disabled>Select District Code</option>
<?php $__currentLoopData = $talukas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taluk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($taluk->taluk_name); ?>"><?php echo e($taluk->taluk_name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\INTERNSHIP\bb\resources\views/pages/get_taluk.blade.php ENDPATH**/ ?>